GTA Vice City - No Clothes Reset by Surya926.

-------------INFO---------------
GTA Vice City have a "feature" that makes tommy's outfit reset to "Street Outfit" when you're Busted or Wasted.
This script "fix" it by retaining the outfit, so you don't have to change to your favourite outfit again when
you're Busted or Wasted.


-----------INSTALLATION-----------
Copy "VC.NoClothesReset.asi" to scripts/mss or root game dir of your GTA Vice City folder.


Credits to spaceeinstein for finding the memory addresses.